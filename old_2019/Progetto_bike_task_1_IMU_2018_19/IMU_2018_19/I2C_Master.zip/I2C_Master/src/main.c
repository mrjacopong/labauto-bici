/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2012 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/******************************************************************************
* File Name     : main.c
* Version       : 1.0
* Description   : File main per gestire IMU
* Author		: Gruppo IMU-BIKE_2018
*******************************************************************************/
/*******************************************************************************
* History : DD.MM.YYYY     Version     Description
*         : 30.11.2018     1.00        First release
*******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include "platform.h"
#include "CMT.h"
#include "imu.h"
#include "mag.h"
#include "AHRS.h"
#include "switches.h"

#define PERIOD 5

int32_t t, last = 0;
char msg[12];
char errorestr[12];
float errore;

IMU_raw imu_raw;		//Dichiarazione strutture
IMU_sens imu_sens;
IMU_temp imu_temp;
MAG_data mag_data;
AHRS_data ahrs_data;


void main(void)
{
	switches_initialize();
	lcd_initialize();
	lcd_clear();
	CMT_init();
	setAHRSFrequency(1000.0/(float)PERIOD);			//Set frequenza di calcolo AHRS
	switch (imu_init(&imu_sens)){					//Test per verificare il corretto funzionamento IMU
		case (0x0):
				lcd_display(LCD_LINE1,"-IMU OK-");
				break;
		case (0x1):
				lcd_display(LCD_LINE1,"i2c ERR");
				break;
		case (0x2):
				lcd_display(LCD_LINE1,"mpu ERR 1");
				break;
		case (0x3):
				lcd_display(LCD_LINE1,"mpu ERR 2");
				break;
		case (0x4):
				lcd_display(LCD_LINE1,"mpu  ERR 3");
				break;
	}
	switch (mag_init(&mag_data)){					//Test per verificare il corretto funzionamento MAG
			case (0x0):
				lcd_display(LCD_LINE2,"-MAG OK-");
				break;
			default:
				lcd_display(LCD_LINE2,"mag ERR");
		}

	calibrationYPR(&msg, &mag_data);				//Calibrazione MAG

	while(1){										//Ciclo infinito. Lettura valori IMU-MAG
		if(imu_read(&imu_raw, &imu_sens, &imu_temp)){
			lcd_display(LCD_LINE3,"imu_read ERR");
		}
		if(mag_read(&mag_data)){
			lcd_display(LCD_LINE4,"mag_read ERR");
		}
		getYPR(&mag_data, &imu_temp, &ahrs_data);

		errore=mag_data.x*mag_data.x+mag_data.y*mag_data.y+mag_data.z*mag_data.z;
		sprintf(errorestr, "%f", (errore-mag_data.ABS)/mag_data.ABS);
		lcd_display(LCD_LINE5,(uint8_t*)errorestr);
	}
}
